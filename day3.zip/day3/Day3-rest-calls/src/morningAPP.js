import { Component } from "react";

class  App extends Component {

  constructor(props){
    super(props);
    this.state = {
      projectName:"Nothing",
      counter:0,
      myName:'blank'
    }

    this.updateProjectName = this.updateProjectName.bind(this);
    this.increaseCounter = this.increaseCounter.bind(this);
    this.changeName = this.changeName.bind(this);
  }
//we will pass textbox reference here
  changeName(name)
  {
    this.setState({myName:name.target.value});
  }


  count=0;
  increaseCounter()
  {

    this.count = this.count + 1;
    this.setState({counter:this.count});
    console.log(this.state.counter);  
    //  this is the line which wil get executed first
    // and then the others
  }
  


  updateProjectName()
  {
  //  this.projectName = "This is a Shopping App";
    this.setState({projectName:'This is a Shopping App'});
    console.log(this.state.projectName);
  }

  greetUser()
  {
    console.log('Good Morning !! Hello and WElcome to Day 3');
  }
  

   render(){
  return (
    <div>
    <h1> I am the Parent App</h1>
        <button onClick={this.greetUser}> Greet </button>
        <button onClick={this.updateProjectName}> Project Name</button>
        {this.state.projectName}

        <hr/>

        <button onClick={this.increaseCounter}> Increase Count  </button>
        {this.state.counter}

        <hr/>
        My Name :<input type="text" value={this.state.myName} onChange={this.changeName}/>

        {this.state.myName}
        
    </div>
  );
}
}

export default App;
