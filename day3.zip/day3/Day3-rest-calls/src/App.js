import { Component } from "react";
import ReactDOM from 'react-dom';
class  App extends Component {

  constructor(props)
  {
    super(props);
    this.state ={
      webPost:[],
      singlePost:{}
    }  
this.getMeThePostData = this.getMeThePostData.bind(this);
  } 


  componentWillMount()
  {
      //do someting here, as the component is go to be loaded
      //initiate a new session
      //start logging
      //capture and store browser info / location

      
  }

  shouldComponentUpdate()
  {
    return false;
  }
  componentDidMount()
  {
    var postIdToSearch = ReactDOM.findDOMNode(this.refs.txtPost).value;
    fetch('https://jsonplaceholder.typicode.com/posts/' + postIdToSearch)
         .then(response => response.json())
         .then(postresult => {              
          // console.log(postresult)
          this.setState({singlePost:postresult});
          console.log(this.state.singlePost);
        
        
        })
         .catch( errMessage => console.log(errMessage));
         
  }
  

  getMeThePostData()
  {

    var postIdToSearch = ReactDOM.findDOMNode(this.refs.txtPost).value;
    fetch('https://jsonplaceholder.typicode.com/posts/' + postIdToSearch)
         .then(response => response.json())
         .then(postresult => {              
          // console.log(postresult)
          this.setState({singlePost:postresult});
          console.log(this.state.singlePost);
        
        
        })
         .catch( errMessage => console.log(errMessage));

         this.forceUpdate();
         
  }

  
 


   render(){
  return (
    <div>
        <h1> Hello REST API </h1>
        <input type="number" placeholder="Enter Post Id to search" ref="txtPost"/>
        <button onClick={ this.getMeThePostData }> Get Post </button>
        

        {/* <table>
          { this.state.webPost.map((data,i)=> {return( <tr>

              <td> {data.id} </td>
              <td> {data.title} </td>
             <td> <img width="80" height="80px" src={data.thumbnailUrl}/></td>

          </tr>)}) }
        </table> */}

        <h3>{this.state.singlePost.id}</h3>
        <h3>{this.state.singlePost.userId}</h3>
        <h3>{this.state.singlePost.title}</h3>
        <h3>{this.state.singlePost.body}</h3>
    </div>
  );
}
}

export default App;
