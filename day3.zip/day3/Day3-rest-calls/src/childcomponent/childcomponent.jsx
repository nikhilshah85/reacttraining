import React, { Component } from 'react';
class Child extends Component
{
    render(){
        return(<div>
            <h1> Hello Child </h1>

{/* 
    <input type="text" placeholder="Enter New Friends Name" ref="txtNewFriend"/>
    <button onClick={this.addNewFriend}> Add </button> */}

            <ul>
            {this.props.friendList.map( (friend,i)  => <li> {friend} </li> )}


          </ul>

          <button onClick={this.props.testgreetUser}> Test Function </button>

          <input type="number" placeholder="Enter A Number" ref="txtChild"/>
          <button onClick={() => this.props.doubleMynumber()}> Call Number </button>
        </div>)
    }
}

export default Child;