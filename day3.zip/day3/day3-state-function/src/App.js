import { Component } from "react";
import ReactDOM from 'react-dom';
import Child from "./childcomponent/childcomponent";
class  App extends Component {

  constructor(props){
    super(props);
    this.state = {
        friends:['Allan','Akshay','Pallavi'],

        greetUser:function(){ alert('Hello I am a Beautiful Function');},
        doubleMynumber:function(num){console.log(num * 2); }
    }     
    this.addNewFriend = this.addNewFriend.bind(this);
  }

    newfriendName = "";
    myArray = [];

  addNewFriend(){
    this.newfriendName = ReactDOM.findDOMNode(this.refs.txtNewFriend).value;    
    console.log(this.newfriendName);
    this.myArray = this.state.friends;
    this.myArray.push(this.newfriendName);

    this.setState({friends:this.myArray});

    
  }

 
   render(){
  return (
    <div>


    <input type="text" placeholder="Enter New Friends Name" ref="txtNewFriend"/>
    <button onClick={this.addNewFriend}> Add </button>

          <ul>
            {this.state.friends.map( (friend,i)  => <li> {friend} </li> )}
          </ul>

      <hr/>
      <Child friendList ={this.state.friends}
            testgreetUser = {this.state.greetUser} doubleMynumber={this.state.doubleMynumber}></Child>


        
    </div>
  );
}
}

export default App;
