
import Transactions from './Transactions/transactions'
function App() {
  return (
    <div className="App">
       <Transactions></Transactions>
    </div>
  );
}

export default App;
