import React, { Component } from 'react'
import './transactions.css'

class Transactions extends Component
{

     

     transactionList = [
        {trNo:101, fromAccount:'XYZ501',toAccount:'ABC145',amount:5000},
        {trNo:102, fromAccount:'XYZ501',toAccount:'ABC145',amount:52000},
        {trNo:103, fromAccount:'XYZ501',toAccount:'ABC145',amount:54000},
        {trNo:104, fromAccount:'XYZ501',toAccount:'ABC145',amount:5000},
        {trNo:105, fromAccount:'XYZ5014',toAccount:'ABC145',amount:52000},
        {trNo:106, fromAccount:'XYZ501',toAccount:'ABC145',amount:5000},
        {trNo:107, fromAccount:'XYZ502',toAccount:'ABC145',amount:50200},
        {trNo:108, fromAccount:'XYZ505',toAccount:'ABC145',amount:51000},
        {trNo:109, fromAccount:'XYZ5324',toAccount:'ABC145',amount:15000},
        {trNo:110, fromAccount:'XYZ501',toAccount:'ABC145',amount:52000},
        {trNo:111, fromAccount:'XYZ456',toAccount:'ABC145',amount:65000},
        {trNo:112, fromAccount:'ABC145',toAccount:'ABC145',amount:75000},
        {trNo:113, fromAccount:'ABC501',toAccount:'ABC145',amount:95000}
    ]

    render(){
        return(
            <div>
                    <table className="table">
                        <thead>
                            <th> Account Number </th>
                            <th> From Account </th>
                            <th> To Account  </th>
                            <th> Amount </th>
                            <th colSpan="3"> Action </th>
                        </thead>
                        <tbody>
                        { this.transactionList.map( (trans,i) => <tr> 
                                <td className="mynumbers"> {trans.trNo} </td>
                                <td> {trans.fromAccount} </td>
                                <td> {trans.toAccount} </td>
                                <td> {trans.amount} </td>
                                <td> <button className="btn btn-primary">Add</button> </td>
                                <td> <button className="btn btn-danger">Delete</button> </td>
                                <td> <button className="btn btn-warning" >Update</button> </td>
                        </tr> ) }
                        </tbody>
                    </table>
            </div>
        )
    }
}

export default Transactions;