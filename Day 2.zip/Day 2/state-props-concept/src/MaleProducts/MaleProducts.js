import React,{Component} from 'react';

class MaleComponent extends Component{

  componentName = "Male Component is my Name";    
   
  constructor(props)
  {
     
    super(props);
  }
  

  render()
  {
    
    return(<div>
      
      <h1>{this.componentName}</h1>
    </div>)
  }

}
export default MaleComponent;
