import React,{Component} from 'react';

class KidsComponent extends Component{

  componentName = "Kids Component is my Name";    
   
  constructor(props)
  {
     
    super(props);
  }
  

  render()
  {
    
    return(<div>
      
      <h1>{this.componentName}</h1>
    </div>)
  }

}
export default KidsComponent;
