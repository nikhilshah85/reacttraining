import React,{Component} from 'react';
import ReactDOM from 'react-dom';

import KidsComponent from './KidsProducts/KidsProducts';
import MaleComponent from './MaleProducts/MaleProducts';
import FemaleProducts from './FeMaleProducts/Femaleproducts';
class App extends Component{

  componentName = "APP is my Name";    
   
  constructor(props)
  {     
    super(props);
    this.addition = this.addition.bind(this);
  }
  
  // function greetings(){
  //   return 'Welcome to React Development';
  // }

  greetings(){
    alert('I am a Greet Function');
    console.log('I am called by a Button');
    return 'Welcome to React Development'
  }


  firstNum = 60;
  secondNum = 30;
  addResult = 0;

  addition(){    
    //  this.addResult = this.firstNum + this.secondNum;
      //return this.addResult;

      

      this.firstNum = ReactDOM.findDOMNode(this.refs.txtNum1).value;
      this.secondNum = ReactDOM.findDOMNode(this.refs.txtNum2).value;

      console.log(this.firstNum);
      console.log(this.secondNum);

      this.forceUpdate();
      this.addResult = parseInt(this.firstNum) + parseInt(this.secondNum);
      console.log(this.addResult);
  }

 
  render()
  {
     return(<div>
      
      <h1> { this.componentName}</h1>
      <hr/>
      <h1> Testing the Functions </h1>

      {/* <h3> Greet : { this.greetings() }</h3>
      <h3> Add : { this.addition(10,20)} </h3> */}

      <button onClick={this.greetings}> Greet </button>

      <input type="number" placeholder="Enter First Number" ref="txtNum1"/>
      <input type="number" placeholder="Enter Second Number" ref="txtNum2" />

      <button onClick={this.addition}> Add </button>

      <h1> Addition : {this.addResult } </h1>
      {/* <button onClick={this.addition }> Addition </button> */}
    </div>)
  }

}
export default App;
