import React,{Component} from 'react';

class FemaleProducts extends Component{

  componentName = "Female Component is my Name";    
   
  constructor(props)
  {
     
    super(props);
  }
  

  render()
  {
    
    return(<div>
      
      <h1>{this.componentName}</h1>
    </div>)
  }

}
export default FemaleProducts;
