import logo from './logo.svg';
import './App.css';
import React, {Component} from 'react';
import Client from './client/client'
class App extends Component{


    
  constructor(props)
  {
    super(props);

    this.state = {
      appName:'React Demo Project',
      teamSize:30,
      description:'This is a Sample app Created using React while in a training',
      projectCost:1500000    
    }

    
  }

    render(){
      return(
        <div>
          <h1> Welcome to React </h1>

          <h3> Application:  {this.state.appName } </h3>
          <h3> Total Members : {this.state.teamSize } </h3>
          <h3> About : {this.state.description  } </h3>
          <h3> Project Value : { this.state.projectCost } </h3>
          <h3> Tax : {this.state.projectCost * 0.1} </h3>
          <h3> Profit : {this.state.projectCost * 0.15} </h3>
          <hr/>
          <h2> Client </h2>
          <Client totalProjectValue={this.state.projectCost}
                  taxPayable = {this.state.projectCost * 0.1}  ></Client>
        </div>
      )
    }

}

export default App;
