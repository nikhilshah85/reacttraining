import React, { Component, useDebugValue } from 'react'

class Client extends Component
{

    render(){
        return(
            <div>
                <h2> I am A Client Component </h2>
                <h2> Project Cost : { this.props.totalProjectValue }</h2>
                <h2> Tax To Govt  : { this.props.taxPayable }</h2>

                <h2>Description : {this.props.description }</h2>
            </div>
        )
    }
}

export default Client;