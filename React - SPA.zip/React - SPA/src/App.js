import {Component} from 'react';
import About from './About/About';
import Contact from './Contact/Contact';
import Home from './Home/home';
import News from './News/news';
import {Route,Switch,Link, Router} from 'react-router-dom';
import Careers from './Careers/Careers';
class  App extends Component {
  render ()
  {
    return(
    <div>
        <h1>  My Orgnization Name  </h1>
        <ul>
   <li>  <Link to="/"> Home </Link> </li> 
   <li>  <Link to="/about"> About </Link> </li>
   <li>   <Link to="/contact"> Contact </Link> </li>
   <li>   <Link to="/news"> News </Link>     </li>
   <li>   <Link to="/careers"> Walk-Inns </Link>     </li>
        </ul>

        <Switch>
          <Route exact path="/" component={Home}/>
          <Route exact path="/about" component={About}/>
          <Route exact path="/contact" component={Contact}/>
          <Route exact path="/news" component={News}/>
          <Route exact path="/careers" component={Careers}/>

          
        </Switch>
        <div>
      {this.props.children}
      </div>
       
    </div>
    )
    }
}

export default App;
