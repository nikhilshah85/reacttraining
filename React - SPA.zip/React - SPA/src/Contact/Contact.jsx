import { Component } from "react";


class  Contact extends Component {
  render ()
  {
    return(
    <div>
        <h1>  Contact </h1>

        <h6>
        A contact page is a common web page on a website for visitors to contact the organization or individual providing the website. 
The page contains one or more of the following items: 
an e-mail address
a telephone number
a postal address, sometimes accompanied with a map showing the location
links to social media
a contact form for a text message or inquiry

A contact page is a common web page on a website for visitors to contact the organization or individual providing the website. 
The page contains one or more of the following items: 
an e-mail address
a telephone number
a postal address, sometimes accompanied with a map showing the location
links to social media
a contact form for a text message or inquiry
In the case of large organizations, the contact page may provide information for several offices (headquarters, field offices, etc.) and departments (customer support, sales, investor relations, press relations, etc.). 
        </h6>
    </div>
    )
    }
}

export default Contact;
