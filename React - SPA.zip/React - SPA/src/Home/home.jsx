import { Component } from "react";

class  Home extends Component {
  render ()
  {
    return(
    <div>
        <h1>  Home </h1>

        <p> Home is where u get good food, homw the place for family, u can watch tv, u can sleep</p>

        <h6>
        A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia

        A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia

        A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia
        A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia
        A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia
        A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia

A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia

A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia
A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia
A home page is the main web page of a website. The term can also refer to one or more pages always shown in a web browser when the application starts up. In this case, it is also known as the start page. Wikipedia
        </h6>
    </div>
    )
    }
}

export default Home;
