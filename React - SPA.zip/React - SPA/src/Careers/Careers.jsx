import { Component } from "react";

class Careers extends Component
{
    render()
    {
        return(<div>
            <h1> Current Opening for Developers</h1>
            <ul>
                <li> React </li>
                <li> Azure </li>
                <li> Angular </li>
                <li> SQL Server </li>
            
            </ul>
            </div>)      
       
       
    }
}
export default Careers;