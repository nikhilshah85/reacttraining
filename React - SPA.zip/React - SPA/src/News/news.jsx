import { Component } from "react";


class  News extends Component {
  render ()
  {
    return(
    <div>
        <h1>  News </h1>

        <h6>
        Dear Friend,
This month, Democracy Now! turns 25—that’s 25 years of bringing you the voices and stories you won’t hear in the corporate media. Democracy Now! has always refused to take government or corporate funding, because nothing is more important to us than our editorial independence. Nothing is more important to us than telling you the truth. But that means we rely on you, our audience, for support. Please make your contribution of $25 or more in honor of our 25th anniversary and help us stay on air for another 25 years. Right now, a generous donor will even DOUBLE your gift, which means it’ll go twice as far! This is a challenging time for us all, but if you're able to make a donation, please do so today. Thank you and remember, wearing a mask is an act of love. Wearing two is even better.
-Amy Goodman

Dear Friend,
This month, Democracy Now! turns 25—that’s 25 years of bringing you the voices and stories you won’t hear in the corporate media. Democracy Now! has always refused to take government or corporate funding, because nothing is more important to us than our editorial independence. Nothing is more important to us than telling you the truth. But that means we rely on you, our audience, for support. Please make your contribution of $25 or more in honor of our 25th anniversary and help us stay on air for another 25 years. Right now, a generous donor will even DOUBLE your gift, which means it’ll go twice as far! This is a challenging time for us all, but if you're able to make a donation, please do so today. Thank you and remember, wearing a mask is an act of love. Wearing two is even better.
-Amy Goodman

Dear Friend,
This month, Democracy Now! turns 25—that’s 25 years of bringing you the voices and stories you won’t hear in the corporate media. Democracy Now! has always refused to take government or corporate funding, because nothing is more important to us than our editorial independence. Nothing is more important to us than telling you the truth. But that means we rely on you, our audience, for support. Please make your contribution of $25 or more in honor of our 25th anniversary and help us stay on air for another 25 years. Right now, a generous donor will even DOUBLE your gift, which means it’ll go twice as far! This is a challenging time for us all, but if you're able to make a donation, please do so today. Thank you and remember, wearing a mask is an act of love. Wearing two is even better.
-Amy Goodman
        </h6>
    </div>
    )
    }
}

export default News;
