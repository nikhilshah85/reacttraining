import { Component } from "react";


class  About extends Component {
  render ()
  {
    return(
    <div>
        <h1>  About </h1>

        <p>
        A page is one side of a leaf of paper, parchment or other material in a book, magazine, newspaper, or other collection of sheets, on which text or illustrations can be printed, written or drawn, to create documents. It can be used as a measure of 
        communicating general quantity of information or more specific quantity Wikipedia
        A page is one side of a leaf of paper, parchment or other material in a book, magazine, newspaper, or other collection of sheets, on which text or illustrations can be printed, written or drawn, to create documents. It can be used as a measure of communicating general quantity of information or more specific quantity Wikipedia
        A page is one side of a leaf of paper, parchment or other material in a book, magazine, newspaper, or other collection of sheets, on which text or illustrations can be printed, written or drawn, to create documents. It can be used as a measure of communicating general quantity of information or more specific quantity Wikipedia
        </p>
    </div>
    )
    }
}

export default About;
