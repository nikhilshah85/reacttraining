let nextToDo = 10;
let number = 100;

export const increaseNumber = num =>({
    type:'INCREMENT_NUMBER',
    newNumber : number++,
    num
})

export const decrementNumber = num =>({
    type:'DECREMENT_NUMBER',
    newNumber : --number,
    num
})

export const addToDo = text => ({
    type:'ADD_TODO',
    id: nextToDo++,
    text
})

export const setVisibilityFilter = filter => ({
    type:'SET_VISIBILITY_FILTER',
    filter
})

export const toggleTodo = id => ({
    type: 'TOGGLE_TODO',
    id
  })

  
export const VisibilityFilters = {
    SHOW_ALL: 'SHOW_ALL',
    SHOW_COMPLETED: 'SHOW_COMPLETED',
    SHOW_ACTIVE: 'SHOW_ACTIVE'
  }
  