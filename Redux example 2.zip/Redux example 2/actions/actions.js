export const ADD_TODO = 'ADD_TODO'
export const REMOVE_TODO = 'REMOVE_TODO'
export const test_todo = 'test_todo'
export const print_MyName = 'print_MyName'
let nextTodoId = 0;

export function addTodo(text) {
   return {
      type: ADD_TODO,
      id: nextTodoId++,
      text
   };
}
export function removeToDo(text)
{
	return{
		type: REMOVE_TODO,
		id: nextTodoId--,
		text
	}
}

export function printMyName()
{
	alert('My name is Nikhil and I am in redux world');
	return{
		type: printMyName,
		result: 'Successful Call'
	}
}

export function testAction()
{
	alert('I am being tested');
	return {
		type: test_todo,
		result: 'Success'
	}
}









