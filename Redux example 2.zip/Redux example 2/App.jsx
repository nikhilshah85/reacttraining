import React, { Component } from 'react'
import { connect } from 'react-redux'
import { addTodo, testAction, printMyName, removeToDo } from './actions/actions.js'
import AddTodo from './components/AddTodo.jsx'
import TodoList from './components/TodoList.jsx'


class App extends Component {
   render() {
     const { dispatch, visibleTodos } = this.props	
      return (
         <div>			
            <AddTodo          
            removeToDo={ text => dispatch(removeToDo(text)) }
             testAction={ testAction }  
             printMyName = {printMyName}
             onAddClick = {text =>  dispatch(addTodo(text))}
            />
				
            <TodoList todos = {visibleTodos}/> 
			
         </div>
      )
   }
}

function select(state) {
   return {
      visibleTodos: state.todos
   }
}

export default connect(select)(App)






