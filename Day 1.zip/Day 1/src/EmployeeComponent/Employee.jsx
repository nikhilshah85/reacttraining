import { getDefaultNormalizer } from '@testing-library/react';
import React, { Component } from 'react';

class Employee extends Component
{

    // this is mandatory
    render()
    {
        var name = 'Nikhil';
        var lastName = 'Shah';
        var employeeInfo = {empNo:101,empName:'Karan',empDesignation:'Sales',empSalary:400,empIsPermenant:true}

        var techList = ['React','Redux','Angular','.Net','Azure','SQL Server', 'Node','Oracle','Backbone']
        function getName(){
            return name + ' ' + lastName;
        }

        //this will return a single HTML Block
        return(
             
             <div>
            
                <div>
                    <h1> Employee Number : { employeeInfo.empNo  } </h1>
                    <h3> Employee Name   : { employeeInfo.empName } </h3>
                    <h3> Employee Designation   : { employeeInfo.empDesignation } </h3>
                    <h3> Employee Salary   : { employeeInfo.empSalary } </h3>
                    <h3> Employee Bonus   : { employeeInfo.empSalary * 0.1 } </h3>
                    <h3> Employee Is Permenant   : { employeeInfo.empIsPermenant ? 'Yes':'No' } </h3>                    
                </div>

              
               
                    {techList.map( (t,i) => <p> {t} </p>)}
                

            </div>
        ) 
    }

}
export default Employee;