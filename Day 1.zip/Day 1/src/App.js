import logo from './logo.svg';
import './App.css';
import  Employee from  '../src/EmployeeComponent/Employee'
function App() {
  return (
    <div className="App">
      {/* <header className="App-header">
        <h1> Welcome to React Development </h1>     
        <h6> Trainer : Nikhil Shah</h6>   
        <h3> Happy Learning !!</h3>
        <h3> Addition Of my Fav Numbers are : { 3 + 5} </h3>
        <h3> Multiplication of My Fav Numbers are : {  3 * 5}</h3>
        <h3> Is 10 Great than 15 ? : { 10 > 15 ? 'Yes':'No' }</h3> */}
    <Employee></Employee>
    <hr/>
    
        {/* <employee></employee> (Employee is an Component)
        <accounts salaryDay="thursday" totalPayment="60000"></accounts> (accounts is a component)

      <employee>
      <manager> </manager>
      <hr></hr>
      </employee> (this is a parenet component) */}

      {/* </header> */}
    </div>
  );
}

export default App;
